<?php

include_once "Class/Monster_Template.php";

class Fly extends Monster_Template {
	const SLOWNESS = 3;
	const TYPE = "flighter";
	const CAN_FALL = false;
	const SPRITE = "VA";
	const COLOR = "0";
	const MAP_DISPLAY = "F";
	const ORDERS = [
		"RIGHT",
		"LEFT"
	];
}